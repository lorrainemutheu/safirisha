import 'package:flutter/material.dart';
import 'package:safirisha/ui/customshapeclipper.dart';

Color firstColor = Color(0xFF0D47A1);
Color secondColor = Color(0xFF1A237E);

/*class Home extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: <Widget>[
          HomeScreenTopPart(),
          HomeScreenBottomPart(),
        ],
      ),
    );
  } 
}*/
class MyHomePage extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return MyHomePageState();
  }
}

class MyHomePageState extends State<MyHomePage>{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: <Widget>[
          Column(
            children: <Widget>[
              Stack(
                children: <Widget>[
        ClipPath(clipper: CustomShapeClipper(),
          child: Container(height : 200.0,
           decoration:BoxDecoration(gradient: LinearGradient(colors: [
            firstColor,
            secondColor
          ],),),
          child: Column(
            children: <Widget>[
              SizedBox(height: 50.0,),
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: <Widget>[
                    Spacer(),
                    Icon(Icons.settings, color: Colors.white,),
                  ],
                ),
              ),
             SizedBox(height: 50.0,),
             Text(
               'Safirisha',
               style:TextStyle(
                 fontFamily: 'Quicksand', 
                 fontSize: 30.0,
                 color: Colors.white,
                 fontWeight: FontWeight.bold,
                 ), 
             textAlign: TextAlign.center,
             ),
             SizedBox(height: 15.0,),
             Text(
               'Twajali hali ya mali yako.',
               style:TextStyle(
                 fontFamily: 'Quicksand', 
                 fontSize: 23.0,
                 color: Colors.white,
                 ), 
             textAlign: TextAlign.center,
             ),
            ],
            ),),)
         ],
              )
            ],
            )
        ],
      ),
    );
  }
}

/* class HomeScreenTopPart extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return new HomeScreenTopPartState();
  }
}

class HomeScreenTopPartState extends State<HomeScreenTopPart>{
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        ClipPath(clipper: CustomShapeClipper(),
          child: Container(height : 160.0,
           decoration:BoxDecoration(gradient: LinearGradient(colors: [
            firstColor,
            secondColor
          ],),),
          child: Column(
            children: <Widget>[
              SizedBox(height: 50.0,),
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: <Widget>[
                    Spacer(),
                    Icon(Icons.settings, color: Colors.white,),
                  ],
                ),
              ),
             SizedBox(height: 50.0,),
             Text(
               'Safirisha',
               style:TextStyle(
                 fontFamily: 'Quicksand', 
                 fontSize: 30.0,
                 color: Colors.white,
                 fontWeight: FontWeight.bold,
                 ), 
             textAlign: TextAlign.center,
             ),
             SizedBox(height: 15.0,),
             Text(
               'Twajali hali ya mali yako.',
               style:TextStyle(
                 fontFamily: 'Quicksand', 
                 fontSize: 23.0,
                 color: Colors.white,
                 ), 
             textAlign: TextAlign.center,
             ),
            ],
          ),),)
      ],
    );
  }  
}

class HomeScreenBottomPart extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return new HomeScreenBottomPartState();
    }
}
    
class HomeScreenBottomPartState extends State<HomeScreenBottomPart>{
  @override
  Widget build(BuildContext context) {
    return ListView(
      children: <Widget>[
          itemCard('Hama na Sisi','assets/hamanasi1.png'),
      ],
      );
  }

Widget itemCard(String title, String imgPath){
    return Padding(
      padding: EdgeInsets.only(left: 15.0, right: 15.0, top: 15.0),
      child: Container(
        height: 150.0,
        width: double.infinity,
        color: Colors.white,
        child: Row(
          children: <Widget>[
            Container(
              width: 140.0,
              height: 150.0,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage(imgPath),fit: BoxFit.cover,
                )
              ),
            ),
            SizedBox(width: 4.0,),
            Column(
              children: <Widget>[
                Text(
                  title,
                  style: TextStyle(
                    fontFamily: 'Quicksand',
                    fontSize: 17.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
            SizedBox(height: 5.0),
            Container(
              width: 175.0,
              child: Text(
                'dfgfdgfdgfd gfd gfd g df gsfd g df gfd g fdg fsd g fd g fdg fd gfd gfd gf dgfrg',
                textAlign: TextAlign.left,
                style: TextStyle(
                  fontFamily: 'Quicksand',
                  color: Colors.grey,
                  fontSize: 12.0
                ),
              ),
              )
              ],
            )
          ],
        ),
      ),
      );
  }
} */



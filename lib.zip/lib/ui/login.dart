import 'package:flutter/material.dart';
import 'package:groovin_material_icons/groovin_material_icons.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

Color redColor = Color(0xFFDD4B39);
Color blueColor = Color(0xFF3b5998);

class LoginPage extends StatefulWidget{
  @override
  _LoginPageSate createState()=>_LoginPageSate();
}

class _LoginPageSate extends State<LoginPage>{
   String _email;
  String   _password;

  final formkey = new GlobalKey<FormState>();

  //google sign
  GoogleSignIn googleauth = new GoogleSignIn();
  FirebaseAuth _auth = FirebaseAuth.instance;

  Future<FirebaseUser> _handleSignIn() async {
    GoogleSignInAccount googleUser = await googleauth.signIn();
    GoogleSignInAuthentication googleAuth = await googleUser.authentication;
    final AuthCredential credential = GoogleAuthProvider.getCredential(
      accessToken: googleAuth.accessToken,
      idToken: googleAuth.idToken,
    );
    final FirebaseUser user = await _auth.signInWithCredential(credential);
    print("signed in " + user.displayName);
    return user;
  }

  checkFields(){
    final form=formkey.currentState;
    if(form.validate()){
      form.save();
      return true;
    }
    return false;
  }



/*  loginUser(){
    if (checkFields()){
      FirebaseAuth.instance.signInWithEmailAndPassword(email: _email, password: _password)
          .then((user){
        print("signed in as ${user.uid}");
        Navigator.of(context).pushReplacementNamed('/homepage');
      }).catchError((e){
        print(e);
      }); 
    }
  }  */

  void loginUser() async {
    if(checkFields()){
      try{
      FirebaseUser user = await FirebaseAuth.instance.signInWithEmailAndPassword(email: _email,password: _password);
      print('Signed in: ${user.uid}');
      Navigator.of(context).pushReplacementNamed('/homepage');
      }
      catch(e){
        print('Error: $e');
      }
    }
  }

  @override
  Widget build(BuildContext context) {

    return new Scaffold(
      backgroundColor: Colors.white,
      body:
      ListView(
        shrinkWrap: true,
        children: <Widget>[
          SizedBox(height:20.0),
          Column(
            children: <Widget>[
              CircleAvatar(
                backgroundColor: Colors.lightBlueAccent,
                radius: 50.0,
                    child: Icon(
                    Icons.local_shipping,
                    color: Colors.black,
                    size: 50.0,
                      ),
                  ),
                  SizedBox(height: 20.0,),
                  Text('Safirisha'),
            ],
            ),

            SizedBox(height: 20.0,),
            Column(
              children: <Widget>[
                Text(
                    'Login With:',
                    style :TextStyle(fontSize: 20.0),
                    ), 
                  SizedBox(height: 20.0,),
              ],
            ), 

            new Container(
            width: MediaQuery.of(context).size.width,
            margin: const EdgeInsets.only(left: 30.0, right: 30.0, top: 20.0),
            child: new Row(
              children: <Widget>[
                new Expanded(
                  child: new Container(
                    margin: EdgeInsets.only(right: 8.0),
                    alignment: Alignment.center,
                    child: new Row(
                      children: <Widget>[
                        new Expanded(
                          child: new FlatButton(
                            shape: new RoundedRectangleBorder(
                              borderRadius: new BorderRadius.circular(30.0),
                            ),
                            color: Colors.white,
                            onPressed: () => {},
                            child: new Container(
                              child: new Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  new Expanded(
                                    child: new FlatButton(
                                      onPressed: (){
                                        Navigator.of(context).pushNamed('/setlocation');
                                      },
                                      padding: EdgeInsets.only(
                                        top: 20.0,
                                        bottom: 20.0,
                                      ),
                                      child: new Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceEvenly,
                                        children: <Widget>[
                                          Icon(
                                              GroovinMaterialIcons.facebook,
                                               color: blueColor,
                                                size: 15.0,
                                            ),
                                          Text(
                                            "Facebook",
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                                color: Color(0Xff3B5998),
                                                ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                new Expanded(
                  child: new Container(
                    margin: EdgeInsets.only(left: 8.0),
                    alignment: Alignment.center,
                    child: new Row(
                      children: <Widget>[
                        new Expanded(
                          child: new FlatButton(
                            shape: new RoundedRectangleBorder(
                              borderRadius: new BorderRadius.circular(30.0),
                            ),
                            color: Colors.white,
                            onPressed: () => {},
                            child: new Container(
                              child: new Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  new Expanded(
                                    child: new FlatButton(
                                      onPressed: (){
                                        _handleSignIn()
                                        .then((FirebaseUser user){
                                        print(user);
                                        Navigator.of(context).pushNamed('/getride');
                                     }) 
                                      .catchError((e) => print(e));
                                      },
                                      padding: EdgeInsets.only(
                                        top: 20.0,
                                        bottom: 20.0,
                                      ),
                                      child: new Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceEvenly,
                                        children: <Widget>[
                                            Image(image: AssetImage("assets/google2.png"),height:32.0,fit: BoxFit.fitHeight),
                                          Text(
                                            "Google",
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                                color: Colors.black,
                                                ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
  
          new Container(
            width: MediaQuery.of(context).size.width,
            margin: const EdgeInsets.only(left: 30.0, right: 30.0, top: 20.0),
            alignment: Alignment.center,
            child: Row(
              children: <Widget>[
                new Expanded(
                  child: new Container(
                    margin: EdgeInsets.all(8.0),
                    decoration: BoxDecoration(border: Border.all(width: 0.25)),
                  ),
                ),
                Text(
                  "OR",
                  style: TextStyle(
                    color: Colors.grey,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                new Expanded(
                  child: new Container(
                    margin: EdgeInsets.all(8.0),
                    decoration: BoxDecoration(border: Border.all(width: 0.25)),
                  ),
                ),
              ],
            ),
          ),


          Center(
            child: Padding(
              padding: const EdgeInsets.all(28.0),
              child: Center(
                  child: Form(
                    key: formkey,
                    child: Center(
                      child: ListView(
                        shrinkWrap: true,
                        children: <Widget>[
          /*  new Padding(padding: EdgeInsets.all(8.0),
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child:IntrinsicWidth(
                child: Column(
                  children: <Widget>[
                     Text(
                            'Login With:',
                             style :TextStyle(fontSize: 20.0),
                            ), 
                        SizedBox(height: 20.0,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: <Widget>[
                            //Expanded(
                               OutlineButton(
                                child: Row(
                                  children: <Widget>[
                                    Icon(GroovinMaterialIcons.facebook, color: blueColor,),
                                    Text(
                                     "Facebook",
                                     style:TextStyle(color: blueColor),
                                   ),
                                  ],
                                  ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30.0),
                               ),
                                color: blueColor,
                                onPressed:(){
                                  Navigator.of(context).pushNamed('/setlocation');
                                 // Navigator.push(context, MaterialPageRoute(builder: (context) => MyHomePage(),
      //  ),);
                                }//LoginUser
                              ),
                              //flex: 1,
                            //),
                            SizedBox(height: 18.0),//,width: 18.0,),
                           
                            SizedBox(height: 18.0),//,width: 18.0,),
                            //Expanded(
                              //flex: 1,
                              OutlineButton(
                                  //child: Text("login with google"),
                                 // child: ImageIcon(AssetImage("images/google1.png"),semanticLabel: "login",),
                                  //Image(image: AssetImage("images/google1.png"),height:28.0,fit: BoxFit.fitHeight),
                                  child:Row(
                                    children: <Widget>[
                                      Image(image: AssetImage("assets/google2.png"),height:28.0,fit: BoxFit.fitHeight),
                                      Text(
                                    "Google",
                                    style: TextStyle(
                                      color: Colors.black,
                                      ),
                                    ),
                                    ],
                                    ),
                                  shape: RoundedRectangleBorder(
                                     borderRadius: BorderRadius.circular(30.0),
                                  ),
                                  color: redColor,
                                  onPressed: (){
                                   // Navigator.push(context, MaterialPageRoute(builder: (context) => MyHomePage(),
                                   _handleSignIn()
                                   //.then((FirebaseUser user) => print(user))
                                  .then((FirebaseUser user){
                                    print(user);
                                    Navigator.of(context).pushNamed('/homepage');
                                  }) 
                                  .catchError((e) => print(e));
                                }
                                ),
                           // )

                          ],
                    ),
                    Text(
                       'OR',
                      style :TextStyle(fontSize: 20.0),
                       ), 
                    SizedBox(height: 20.0,),
                  ],

                ),
              ),
              ),
            ),), */
            
            _input("required email",false,"Email",'Enter your Email',(value) => _email = value),
            SizedBox(width: 20.0,height: 20.0,),
            _input("required password",true,"Password",'Password',(value) => _password = value),
                        
            new Padding(padding: EdgeInsets.all(2.0),
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(2.0),
                child: Column(
                  children: <Widget>[
                    SizedBox(height: 15.0),

                    RaisedButton(
                        child: Text(
                          "Login",
                          style: TextStyle(
                            color: Colors.white,
                          ),
                          ),  
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30.0),
                        ),
                        color: Colors.blueAccent,
                        onPressed: loginUser

                          //Navigator.of(context).pushNamed('/signup');
                         // Navigator.push(context, MaterialPageRoute(builder: (context) => MyHomePage(),
       // ),);
                        ),
                  ],
                ),
              ),
            ),
            ),           
          ],
                      ),
                    ),
                  )
              ),
            ),
          ),
          //SizedBox(height: 15.0),
               /* Expanded(
                    child:Container( //added container with media query
                    width: MediaQuery.of(context).size.width,
                    margin: const EdgeInsets.all(0.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Align(
                          alignment: Alignment.bottomCenter,
                          child: ButtonBar(
                            alignment: MainAxisAlignment.center,
                            children: <Widget>[
                              FlatButton(
                              child: Text(
                                'forgot password?',
                                style: TextStyle(fontFamily: 'Quicksand'),
                              ),
                              onPressed: (){},
                              ),

                              //SizedBox(width: 15.0),
                              FlatButton(
                              //InkWell(
                                child: Text(
                                  'create account',
                                  style: TextStyle(
                                      color: Colors.blue,
                                      fontFamily: 'Quicksand', //'Montserrat',
                                      fontWeight: FontWeight.bold,
                                      decoration: TextDecoration.underline),
                                ),
                                onPressed: (){
                                  Navigator.of(context).pushNamed('/signup');
                                  formkey.currentState.reset();
                                },
                            // ),
                          ),
                    ],
                    ),
                   ),
                      ],
                    ),
                  ),
                 ), */ 
        ],
      ) ,
    );
  }
  Widget _input(String validation,bool ,String label,String hint, save){

    return new TextFormField(
      decoration: InputDecoration(
          hintText: hint,
          labelText: label,
          contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 20.0),
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(20.0)
          ),

      ),
      obscureText: bool,
      validator: (value)=>
      value.isEmpty ? validation: null,
      onSaved: save , 

    );

  }
}
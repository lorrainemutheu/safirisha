import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';


class SignUpPage extends StatefulWidget {
  SignUpPage({Key key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => new _SignUpPageState();
  }


class _SignUpPageState extends State<SignUpPage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final GlobalKey<FormState> _formKey = new GlobalKey<FormState>();

  bool _autoValidate = false;
  String firstName;
  String lastName;
  String password;
  String email;
  String phoneNo;
  bool _termsChecked = false;
  int radioValue = -1;

  String _validatePassword(String value) {
    if (value.length < 8) {
      return 'The Password must be at least 8 characters.';
    }
    return null;
  }

  String validateName(String value) {
    if (value.length < 3)
      return 'Name must be more than 2 characters';
    else
      return null;
  }

  String validateMobile(String value) {
    if (value.length != 10)
      return 'Mobile Number must be of 10 digit';
    else
      return null;
  }

  String validateEmail(String value) {
    Pattern pattern =
        r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    RegExp regex = new RegExp(pattern);
    if (!regex.hasMatch(value))
      return 'Enter Valid Email';
    else
      return null;
  }

  /* void handleRadioValueChange(int value) {
    print(value);
    setState(() => radioValue = value);
  }

  void _validateInputs() {
  final form = _formKey.currentState;
  if (form.validate()) {
    // Text forms has validated.
    // Let's validate radios and checkbox
    if (radioValue < 0) {
      // None of the radio buttons was selected
      _showSnackBar('Please select your gender');
    } else if (!_termsChecked) {
      // The checkbox wasn't checked
      _showSnackBar("Please accept our terms");
    } else {
      // Every of the data in the form are valid at this point
      form.save();
    }
  } else {
    setState(() => _autoValidate = true);
    _formKey.currentState.save(); // Save our form now.
  }
} */

  void _showSnackBar(message) {
    final snackBar = new SnackBar(
      content: new Text(message),
    );
    _scaffoldKey.currentState.showSnackBar(snackBar);
  }
  

   void submit() async{
    // First validate form.
    if (this._formKey.currentState.validate()) {
      if(!_termsChecked){
      _showSnackBar("Please accept our terms");
    }else{
      _formKey.currentState.save(); // Save our form now.
       FirebaseUser user = await FirebaseAuth.instance.createUserWithEmailAndPassword(email:email,password:password);
      print('Registered user: ${user.uid}');
    }
    }
  } 

  @override
  Widget build(BuildContext context) {
   // final Size screenSize = MediaQuery.of(context).size;
    return new Scaffold(
      key: this._scaffoldKey,
      appBar: new AppBar(
        title: new Text('Registration'),
      ),
      body: new Container(
        padding: new EdgeInsets.all(20.0),
        child: new Form(
          key: this._formKey,
          autovalidate: _autoValidate,
          child: new ListView( //change to column if problem arises
            children: <Widget>[
              new TextFormField(// Use email input type for emails.
                decoration: new InputDecoration(
                  hintText: 'John',
                  labelText: 'First Name'
                ),
                validator: this.validateName,
                onSaved: (String value) {
                  this.firstName = value;
                }
              ),
              new TextFormField(// Use email input type for emails.
                decoration: new InputDecoration(
                  hintText: 'Mkubwa',
                  labelText: 'Last Name'
                ),
                validator: this.validateName,
                onSaved: (String value) {
                  this.lastName = value;
                }
              ),
              new TextFormField(
                keyboardType: TextInputType.emailAddress, // Use email input type for emails.
                decoration: new InputDecoration(
                  hintText: 'you@example.com',
                  labelText: 'E-mail Address'
                ),
                validator: this.validateEmail,
                onSaved: (String value) {
                  this.email = value;
                }
              ),
              new TextFormField(
                keyboardType: TextInputType.phone, 
                decoration: new InputDecoration(
                  hintText: '07********',
                  labelText: 'Phone number'
                ),
                validator: this.validateMobile,
                onSaved: (String value) {
                  this.phoneNo = value;
                }
              ),
              new TextFormField(
                obscureText: true, // Use secure text for passwords.
                decoration: new InputDecoration(
                  hintText: 'Password',
                  labelText: 'Enter your password'
                ),
                validator: this._validatePassword,
                onSaved: (String value) {
                  this.password = value;
                }
              ),
              new TextFormField(
                obscureText: true, // Use secure text for passwords.
                decoration: new InputDecoration(
                  hintText: 'Retype your Password',
                  labelText: 'Confirm password'
                ),
                validator: this._validatePassword,
                onSaved: (String value) {
                  this.password = value;
                }
              ),
              SizedBox(
                height: 20.0,
              ),
              Text(
                'Please select your gender',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(
                height: 20.0,
              ),
             /* new RadioListTile<int>(
                  title: new Text('Male'),
                  value: 0,
                  groupValue: radioValue,
                  onChanged: handleRadioValueChange),
              new RadioListTile<int>(
                  title: new Text('Female'),
                  value: 1,
                  groupValue: radioValue,
                  onChanged: handleRadioValueChange),
               */
              new SizedBox(
                height: 40.0,
              ),

             new CheckboxListTile(
                title: new Text(
                  'I agree to the Terms and Conditions of Safirisha',
                  style:TextStyle(
                    color:Colors.blueAccent,
                  ),
                ),
                value: _termsChecked,
                onChanged: (bool value) =>
                setState(() => _termsChecked = value)),
                

                new SizedBox(
                   height: 25.0,
                ),
                
                new RaisedButton(
                  child: new Text(
                    'Register',
                    style: new TextStyle(
                      color: Colors.white
                    ),
                  ),
                  shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30.0),
                  ),
                  onPressed: this.submit,//_validateInputs,
                  color: Colors.green
                ),

              SizedBox(height: 15.0),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Text(
                          'Already have an account?',
                          style: TextStyle(fontFamily: 'Quicksand'),//'Montserrat'),
                        ),
                        //InkWell(
                          FlatButton(
                          child: Text(
                            'Login',
                            style: TextStyle(
                                color: Colors.blue,
                                fontFamily: 'Quicksand', //'Montserrat',
                                fontWeight: FontWeight.bold,
                                decoration: TextDecoration.underline),     
                          ), 
                          onPressed: () {
                            Navigator.of(context).pushNamed('/login');
                            _formKey.currentState.reset();
                          },
                          )
                       // )
                      ],
                    ),
              /* new Container(
                //width: screenSize.width,
                padding: const EdgeInsets.only(left: 40.0, top: 30.0, bottom: 30.0),
                child: new RaisedButton(
                  child: new Text(
                    'Register',
                    style: new TextStyle(
                      color: Colors.white
                    ),
                  ),
                  shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30.0),
                  ),
                  onPressed: _validateInputs,//this.submit,
                  color: Colors.greenAccent
                ),
                margin: new EdgeInsets.only(
                  top: 20.0
                ),
              ), */
            ],
          ),
        )
      ),
    );
  }
}

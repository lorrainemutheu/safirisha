import 'package:flutter/material.dart';
//import './widgets/star_rating.dart';

class Ratings extends StatefulWidget{
  @override
  State<StatefulWidget> createState() => _RatingsState();
}
  
  class _RatingsState extends State<Ratings> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.greenAccent,
      appBar: AppBar(
        title: Text("Ratings"),
        leading: IconButton(
            icon : Icon(Icons.arrow_back),
            onPressed: (){}
        ),
        backgroundColor: Colors.amberAccent,
      ),
      body: Container(
        padding: const EdgeInsets.all(8.0),
        height:700.0,
        width: 400.0,
        color:Color(0xff985de3),
        child: Stack(
          children: <Widget>[
            driverRating("Lorraine Mutheu","KBS 985"),
            Positioned(
              top: 0.0,
              left: 100.0,
              child: Container(
                width: 160.0,
                height: 160.0,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  image: DecorationImage(
                    fit: BoxFit.fill,
                    image: AssetImage('assets/kuikariuki.jpg'),
                  ),
                ),
              ),
            ),
          ],
         ),
        ),
                     /* Container(
                        padding: EdgeInsets.fromLTRB(20.0,40.0,20.0,40.0),
                        child: Stack(
                          children: <Widget>[
                            Positioned(
                              //left: 20.0,
                              child: Container(
                                width: 300,
                                height: 350,
                                decoration: BoxDecoration(
                                  color: Colors.amber,
                                  borderRadius: BorderRadius.circular(10.0),
                                  image: DecorationImage(
                                    image:AssetImage('assets/kuikariuki.jpg'),
                                    fit: BoxFit.cover,
                                  )
                                ),
                              ),
                            ),
                          ],
                        ),
                      ), */
                );
               }
            
          Center driverRating(String driverName, String driverPlate) {
              return Center(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Color(0xff5a340b),
                      gradient: LinearGradient(
                        colors: [Color(0xff5a340b), Color(0xff5a340b)],
                        begin: Alignment.centerRight,
                        end:Alignment(-1.0,-1.0),
                      )
                    ),
                    child: Container(
                      width: 500.0,
                      height: 400.0,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12.0),
                        color: Color(0xff5a348b),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Padding(
                                padding: const EdgeInsets.only(top: 24.0),
                                child: Text(
                                  driverName,
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 24.0,
                                  ),
                                ),
                              ),

                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  driverPlate,
                                  style: TextStyle(
                                    color: Colors.amber,
                                    fontSize: 18.0
                                  ),
                                ),
                              ),

                              Padding(
                                padding: const EdgeInsets.only(top:8.0),
                                child: Row(
                                  children: <Widget>[
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Row(
                                        children: <Widget>[
                                          Icon(
                                            Icons.art_track,
                                            size: 20.0,
                                          ),
                                          Text(
                                            "Here and now",
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 20.0,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),

                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Row(
                                      children: <Widget>[
                                        Icon(
                                          Icons.favorite,
                                          size:20.0
                                        ),
                                        Text(
                                            "Here and now",
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 20.0,
                                            ),
                                          ),
                                      ],
                                    ),
                                  ),  
                                  ],
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              );
          }
  }
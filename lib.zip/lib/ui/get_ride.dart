import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
//import './widgets/modal_trigger.dart';
//import './widgets/show_driver.dart';
//import './widgets/functionalButton.dart';

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  _MyHomePageState();

  GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey();
  Completer<GoogleMapController> _controller = Completer();
  Map<PolylineId, Polyline> polylines = <PolylineId, Polyline>{};
  //int _polylineIdCounter = 1;
  PolylineId selectedPolyline;

  // Values when toggling polyline color
  int colorsIndex = 0;
  List<Color> colors = <Color>[
    Colors.purple,
    Colors.red,
    Colors.green,
    Colors.pink,
  ];

  // Values when toggling polyline width
  int widthsIndex = 0;
  List<int> widths = <int>[10, 20, 5];

  int jointTypesIndex = 0;
  List<JointType> jointTypes = <JointType>[
    JointType.mitered,
    JointType.bevel,
    JointType.round
  ];

  // Values when toggling polyline end cap type
  int endCapsIndex = 0;
  List<Cap> endCaps = <Cap>[Cap.buttCap, Cap.squareCap, Cap.roundCap];

  // Values when toggling polyline start cap type
  int startCapsIndex = 0;
  List<Cap> startCaps = <Cap>[Cap.buttCap, Cap.squareCap, Cap.roundCap];

  // Values when toggling polyline pattern
  int patternsIndex = 0;
  List<List<PatternItem>> patterns = <List<PatternItem>>[
    <PatternItem>[],
    <PatternItem>[
      PatternItem.dash(30.0),
      PatternItem.gap(20.0),
      PatternItem.dot,
      PatternItem.gap(20.0)
    ],
    <PatternItem>[PatternItem.dash(30.0), PatternItem.gap(20.0)],
    <PatternItem>[PatternItem.dot, PatternItem.gap(10.0)],
  ];

  //GoogleMapController _mapController;

  static final CameraPosition _cameraPosition = CameraPosition(
    target: LatLng(-8.913025, 13.202462),
    zoom: 17.0,
  );

  @override
  void initState() {
    //_mapController.mar();
    super.initState();
  }

  /*void _onPolylineTapped(PolylineId polylineId) {
    setState(() {
      selectedPolyline = polylineId;
    });
  } */

  /* void _addHomePoly() {
    _homeCameraPosition();
    final String polylineIdVal = 'polyline_id_$_polylineIdCounter';
    _polylineIdCounter++;
    final PolylineId polylineId = PolylineId(polylineIdVal);

    final Polyline polyline = Polyline(
      polylineId: polylineId,
      consumeTapEvents: true,
      color: Colors.black,
      width: 5,
      points: _createHomePoints(),
      onTap: () {
        _onPolylineTapped(polylineId);
      },
    );

    setState(() {
      polylines[polylineId] = polyline;
    });
  } */

  /* void _addGymPoly() {
    _gymCameraPosition();
    final String polylineIdVal = 'polyline_id_$_polylineIdCounter';
    _polylineIdCounter++;
    final PolylineId polylineId = PolylineId(polylineIdVal);

    final Polyline polyline = Polyline(
      polylineId: polylineId,
      consumeTapEvents: true,
      color: Colors.black,
      width: 5,
      points: _createGymPoints(),
      onTap: () {
        _onPolylineTapped(polylineId);
      },
    );

    setState(() {
      polylines[polylineId] = polyline;
    });
  } */

  /* void _addWorkPoly() {
    _workCameraPosition();
    final String polylineIdVal = 'polyline_id_$_polylineIdCounter';
    _polylineIdCounter++;
    final PolylineId polylineId = PolylineId(polylineIdVal);

    final Polyline polyline = Polyline(
      polylineId: polylineId,
      consumeTapEvents: true,
      color: Colors.black,
      width: 5,
      points: _createWorkPoints(),
      onTap: () {
        _onPolylineTapped(polylineId);
      },
    );

    setState(() {
      polylines[polylineId] = polyline;
    });
  } */

  /* Future<void> _homeCameraPosition() async {
    final GoogleMapController controller = await _controller.future;
    controller.animateCamera(CameraUpdate.newCameraPosition(CameraPosition(
      target: LatLng(-8.913394, 13.202649),
      zoom: 18.10,
    )));
  }

  Future<void> _gymCameraPosition() async {
    final GoogleMapController controller = await _controller.future;
    controller.animateCamera(CameraUpdate.newCameraPosition(CameraPosition(
      target: LatLng(-8.912014, 13.204197),
      zoom: 18.5,
    )));
  }

  Future<void> _workCameraPosition() async {
    final GoogleMapController controller = await _controller.future;
    controller.animateCamera(CameraUpdate.newCameraPosition(CameraPosition(
      target: LatLng(-8.914843, 13.201518),
      zoom: 18.5,
    )));
  } */

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      key: _scaffoldKey,
      bottomSheet: Container(
        height: 300,
        decoration: BoxDecoration(
          color: Colors.black
        ),
        child: Column(

        ),
      ),
      drawer: Drawer(
        child: ListView(
          children: <Widget>[
            UserAccountsDrawerHeader(
              decoration: BoxDecoration(color: Colors.orangeAccent),
              accountName: Text("Lorraine Mutheu"),
              accountEmail: Row(
                children: <Widget>[
                  Text("My Account"),
                  Icon(
                    Icons.account_circle,
                    color: Colors.white,
                    size: 12,
                  )
                ],
              ),
              currentAccountPicture: ClipOval(
                child: Image.asset(
                  "assets/kuikariuki.jpg",
                  width: 10,
                  height: 10,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  linkMenuDrawer('Home',Icon(Icons.home), () {
                    Navigator.pushNamed(context, '/payment');
                  }),
                  linkMenuDrawer('My wallet',Icon(Icons.account_balance_wallet), () {
                    Navigator.pushNamed(context, '/your_trip');
                  }),
                  linkMenuDrawer('History',Icon(Icons.history), () {
                    Navigator.of(context).pushNamed('/history');
                    //Navigator.pushNamed(context, '/history');
                  }),
                  linkMenuDrawer('Notifications',Icon(Icons.notifications), () {
                    Navigator.pushNamed(context, '/notifications');
                  }),
                  linkMenuDrawer('Invite Friends',Icon(Icons.card_giftcard), () {
                    Navigator.pushNamed(context, '/settings');
                  }),
                  linkMenuDrawer('Settings',Icon(Icons.settings), () {
                    Navigator.pushNamed(context, '/settings');
                  }),
                  linkMenuDrawer('Logout',Icon(Icons.input), () {
                    Navigator.pushNamed(context, '/settings');
                  }),
                  /*Divider(
                    color: Colors.black45,
                  ),
                  linkMenuDrawer('Drive With Uber', () {}),
                  linkMenuDrawer('Legal', () {}),*/
                ]),
          ],
        ),
      ),
      body: Stack(
        children: <Widget>[
          GoogleMap(
            polylines: Set<Polyline>.of(polylines.values),
            mapType: MapType.normal,
            initialCameraPosition: _cameraPosition,
            onMapCreated: (GoogleMapController controller) {
              _controller.complete(controller);
              //_initCameraPosition();
            },
          ),

       /*   Positioned(
          top: 50.0,
          right: 15.0,
          left: 15.0,
          child: Container(
            height: 50.0,
            width: double.infinity,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(3.0),
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                    color: Colors.grey,
                    offset: Offset(1.0, 5.0),
                    blurRadius: 10,
                    spreadRadius: 3)
              ],
            ),
            child: TextField(
              cursorColor: Colors.black,
              //controller: locationController,
              decoration: InputDecoration(
                icon: Container(margin: EdgeInsets.only(left: 20, top: 5), width: 10, height: 10, child: Icon(Icons.location_on, color: Colors.black,),),
                hintText: "pick up",
                border: InputBorder.none,
                contentPadding: EdgeInsets.only(left: 15.0, top: 16.0),
              ),
            ),
          ),
        ),

        Positioned(
          top: 105.0,
          right: 15.0,
          left: 15.0,
          child: Container(
            height: 50.0,
            width: double.infinity,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(3.0),
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                    color: Colors.grey,
                    offset: Offset(1.0, 5.0),
                    blurRadius: 10,
                    spreadRadius: 3)
              ],
            ),
            child: TextField(
              cursorColor: Colors.black,
             // controller: destinationController,
              textInputAction: TextInputAction.go,
             // onSubmitted: (value){
             //   sendRequest(value);
             // },
              decoration: InputDecoration(
                icon: Container(margin: EdgeInsets.only(left: 20, top: 5), width: 10, height: 10, child: Icon(Icons.local_taxi, color: Colors.black,),),
                hintText: "destination?",
                border: InputBorder.none,
                contentPadding: EdgeInsets.only(left: 15.0, top: 16.0),
              ),
            ),
          ),
        ), */

         /* Positioned(
            top: 100.0,
            right: 15.0,
            left: 15.0,
            child: Container(
              height: 50.0,
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(3.0),
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                      color: Colors.grey,
                      offset: Offset(1.0, 5.0),
                      blurRadius: 15,
                      spreadRadius: 3)
                ],
              ),
              child: TextField(
                decoration: InputDecoration(
                  icon: Container(margin: EdgeInsets.only(left: 20, top: 18), width: 10, height: 10, decoration: BoxDecoration(color: Colors.black)),
                  hintText: "Where to?",
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.only(left: 15.0, top: 16.0),
                ),
              ),
            ),
          ), */
          Positioned(
              top: 30,
              left: 6,
              child: IconButton(
                icon: Icon(Icons.menu),
                color: Colors.black,
                onPressed: () {
                  _scaffoldKey.currentState.openDrawer();
                },
              )),

              Positioned(
              bottom:50.0,
              right: 5.0,
              left: 5.0,
              child:Center(
               child:Container(
                margin: EdgeInsets.only(left: 10.0, right: 10.0),
                child:SizedBox(
                  height: 260.0,
                  child: _buildCard(context),
                ),
               ),
               ),
              ), 

            

          /* Positioned(
            child: Align(
              alignment: Alignment.bottomCenter,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  FunctionalButton(
                    icon: Icons.work,
                    title: "Work",
                    onPressed: _addWorkPoly,
                  ),
                  FunctionalButton(
                    icon: Icons.home,
                    title: "Home",
                    onPressed: _addHomePoly,
                  ),
                  FunctionalButton(
                    icon: Icons.timer,
                    title: "Zinc Gym",
                    onPressed: _addGymPoly,
                  ), 
                ],
              ),
            ),
          ), */
       /*   Positioned(
          bottom:0.0,
          child: Container(
            width:MediaQuery.of(context).size.width,
            color:Colors.orangeAccent,
            margin: const EdgeInsets.all(0.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Align(
                  alignment: Alignment.bottomCenter,
                  //child: ShowDriverPage(),
                    child:Theme(
                    data: Theme.of(context).copyWith(canvasColor: Colors.transparent),
                    child: ModalTrigger(),
                  ), 
                )
              ]
            )
          )
        ), */
        ],
      ),
    );
  } 

/*  LatLng _createLatLng(double lat, double lng) {
    return LatLng(lat, lng);
  }

  List<LatLng> _createHomePoints() {
    final List<LatLng> points = <LatLng>[];
    points.add(_createLatLng(-8.913012, 13.202450));
    points.add(_createLatLng(-8.913297, 13.202253));
    points.add(_createLatLng(-8.913752, 13.202803));
    points.add(_createLatLng(-8.913455, 13.203063));
    points.add(_createLatLng(-8.913012, 13.202450));
    return points;
  }

  List<LatLng> _createGymPoints() {
    final List<LatLng> points = <LatLng>[];
    points.add(_createLatLng(-8.911857, 13.203656));
    points.add(_createLatLng(-8.911580, 13.204369));
    points.add(_createLatLng(-8.912060, 13.204649));
    points.add(_createLatLng(-8.912406, 13.204128));
    points.add(_createLatLng(-8.911857, 13.203656));
    return points;
  }

  List<LatLng> _createWorkPoints() {
    final List<LatLng> points = <LatLng>[];
    points.add(_createLatLng(-8.914580, 13.202106));
    points.add(_createLatLng(-8.915066, 13.201708));
    points.add(_createLatLng(-8.915269, 13.201441));
    points.add(_createLatLng(-8.915345, 13.201232));
    points.add(_createLatLng(-8.915301, 13.201075));
    points.add(_createLatLng(-8.915058, 13.200855));
    points.add(_createLatLng(-8.914824, 13.201195));
    points.add(_createLatLng(-8.914180, 13.201826));
    points.add(_createLatLng(-8.914580, 13.202106));

    return points;
  } */
}

Card _buildCard(BuildContext context){
             return Card(
                child: Column(
                   mainAxisSize: MainAxisSize.min,
                   children: <Widget>[
                     Container(
                      color: Colors.grey[200], 
                       child: ListTile(
                       leading: Container(
                            alignment: Alignment.topLeft,
                            height: 50.0,
                            width: 50.0,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(25.0),
                                border: Border.all(
                                    color: Colors.white,
                                    style: BorderStyle.solid,
                                    width: 2.0),
                                image: DecorationImage(
                                    image: AssetImage('assets/kuikariuki.jpg')
                                )
                                ),
                          ),
                       title: Text('John Doe',style: TextStyle(fontWeight: FontWeight.w400,)),
                       subtitle: Text('★4.9'),
                       //trailing: Icon(Icons.add_call),
                       trailing: CircleAvatar(
                        backgroundColor: Colors.lightGreenAccent,
                        radius: 20.0,
                            child: Icon(
                            Icons.add_call,
                            color: Colors.black,
                              ),
                          ),
                      /* trailing: Row(
                         children: <Widget>[
                           Icon(Icons.message),
                           SizedBox(width: 3.0,),
                           Icon(Icons.call),
                         ],
                       ), */
                     ),
                     ),
                    // Divider(color: Colors.grey,),
                    Container(
                      height: 1.0,
                      color: Colors.grey,
                    ),
                    SizedBox(height: 15.0,),
                     Row(
                       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                       children: <Widget>[
                            Icon(Icons.local_shipping, color: Colors.black,size: 50.0,),
                            summaryBuilder('DISTANCE','0.2km'),
                            summaryBuilder('TIME','5min'),
                            summaryBuilder('PRICE','ksh 200'),
                       ],
                     ),
                    SizedBox(height:30.0,),
               RawMaterialButton(
                    onPressed: () {
                      showConfirmation(context);
                    },
                    fillColor: Colors.orangeAccent,
                    constraints: BoxConstraints(minHeight: 50,minWidth: 200),
                    elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
                    child: Text('CONFIRM'),
                    textStyle: TextStyle(
                    //fontSize: 16,
                    fontFamily: 'QuickSand',
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                ),
              ),  
                   ],
                ),
             );
} 

        Future<bool> showConfirmation(context){
            return showDialog(
               context:context,
               barrierDismissible: false,
               builder: (BuildContext context){
                 return Dialog(
                   shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
                   child: Container(
                     height: 320.0,
                     width: 200.0,
                     decoration: BoxDecoration(
                       borderRadius: BorderRadius.circular(20.0),
                     ),
                     child: Column(
                       children: <Widget>[
                         Stack(
                           children: <Widget>[
                             Container(
                               height: 150.0,
                             ),
                             Container(
                               height: 100.0,
                               decoration: BoxDecoration(
                                 borderRadius: BorderRadius.only(
                                   topLeft: Radius.circular(10.0),
                                   topRight: Radius.circular(10.0),
                                 ),
                                 color:Colors.amberAccent
                               ),
                             ),

                             Positioned(
                               top:50.0,
                               left:80.0,
                               child: Container(
                                 height: 90.0,
                                 width: 90.0,
                                 child:CircleAvatar(
                                  backgroundColor: Colors.amber,
                                  radius: 50.0,
                                      child: Icon(
                                      Icons.check,
                                      color: Colors.black,
                                      size: 60.0,
                                        ),
                                    ),
                                /* decoration: BoxDecoration(
                                   borderRadius: BorderRadius.circular(45.0),
                                   border: Border.all(
                                     color: Colors.white,
                                     style: BorderStyle.solid,
                                     width:2.0,
                                     ),  
                                 ), */
                               //  child: Icon(Icons.check,size:50.0),
                               ),
                             ),
                           ],
                         ),
                         SizedBox(height: 10.0,),
                         Padding(
                           padding: EdgeInsets.all(10.0),
                           child:Column(
                             children:<Widget>[
                               Text(
                                'Booking Successful',
                                style: TextStyle(fontFamily: 'Quicksand', fontSize: 20.0,fontWeight:FontWeight.w900),
                              ),
                              Container(
                                margin: const EdgeInsets.only(top: 8.0),
                                child:Text(
                                  'Your booking has been confirmed',
                                  style: TextStyle(fontWeight: FontWeight.w300),
                                  ),
                              ),
                               Text(
                                'Driver will pick you up in 2 minutes',
                                style: TextStyle(fontWeight: FontWeight.w300),
                               ),
                             ]
                           ), 
                         ),
                        SizedBox(height: 15.0,),
                        FlatButton(
                          child: Center(
                            child: Text(
                              'OKAY',
                              style: TextStyle(
                                fontFamily: 'QuickSand',
                                fontSize: 20.0,
                                color:Colors.orange
                              ),
                              ),
                          ),
                        onPressed: (){
                           Navigator.of(context).pop();
                         },
                         color: Colors.transparent, 
                        )
                       ],
                     ),
                   ),
                 );
               }

            );
        }

        Widget summaryBuilder(String title, String summary) {
           final Color tintColor = Colors.grey;
            return Column(
              children: <Widget>[
                 Text(title, style: TextStyle(fontSize: 12.0,
                  fontWeight: FontWeight.w600, color: tintColor),),
                 Container(
                  margin: const EdgeInsets.only(top: 5.0),
                  child: Text(summary,style: TextStyle(fontWeight: FontWeight.w400),),
                )
              ],
            );
        }

        Widget linkMenuDrawer(String title,Icon icon, Function onPressed) {
          return InkWell(
            onTap: onPressed,
            splashColor: Colors.black,
            child: Container(
              padding: EdgeInsets.symmetric(vertical: 13, horizontal: 15),
              width: double.infinity,
              child:Row(
                children: <Widget>[
                  icon,
                  SizedBox(width: 8.0,),
                  Text(
                    title,
                    style: TextStyle(fontSize: 15.0),
                  ),
                ],
              ),
            ),
          );
        } 
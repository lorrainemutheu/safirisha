 /* import 'package:flutter/material.dart';
 import 'package:geolocation/geolocation.dart';
 //import 'package:google_maps_flutter/google_maps_flutter.dart';
 import 'package:flutter_map/flutter_map.dart';
 import 'package:latlong/latlong.dart';


 class GeolocationPage extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return GeolocationPageState();
      } 
     }
    
 class GeolocationPageState extends State<GeolocationPage>{
   
   MapController controller = new MapController();

   getPermission() async{
     final GeolocationResult result = await Geolocation.requestLocationPermission(
       const LocationPermission(
         android: LocationPermissionAndroid.fine,
         ios: LocationPermissionIOS.always
       )
     );
     return result;
   }

   getLocation(){
     return getPermission().then((result) async{
       if(result.isSuccesful){
         final coords = Geolocation.currentLocation(accuracy:LocationAccuracy.best);
         return coords;
       }
     });
   }

   buildMap(){
     getLocation().then((response){
        if(response.isSuccessful){
          response.listen((value){
            controller.move(
              new LatLng(value.location.latitude, value.location.longitude), 
              15.0);
          });
        }
     });
   }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
       body: new FlutterMap(
         mapController: controller,
         options: new MapOptions(center:buildMap(), minZoom:5.0),
         layers: [
           new TileLayerOptions(
             urlTemplate: 
             "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
             subdomains: ['a','b','c']
           ),
         ],
       ),
    );
  }
}

*/
import 'dart:ui';
import 'package:flutter/material.dart';

class AddHistory{
  
  final String pickup, destination, cost;

  final Color status;

  AddHistory(this.pickup, this.destination, this.cost, this.status);

}
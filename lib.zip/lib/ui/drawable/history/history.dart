import 'package:flutter/material.dart';
import './add_history.dart';

class HistoryPage extends StatefulWidget{
  @override
  _HistoryPageState createState() => _HistoryPageState();
    
  }
  
  class _HistoryPageState extends State<HistoryPage>{

    final List<AddHistory> history = List();

    void initState(){
       super.initState();

       setState(() {
         history.add(new AddHistory("University Way", "Nyayo Estate Embakasi", "ksh 600", Colors.red));
         history.add(new AddHistory("Kitusuru", "UON Main Campus", "ksh 500", Colors.purple));
         history.add(new AddHistory("Syokimau", "Mamlaka Road", "ksh 1000", Colors.amber));
         history.add(new AddHistory("Nairobi Primary", "Gigiri", "ksh 400", Colors.green));
       });
    }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: Stack(
          children: <Widget>[
            Positioned(
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height/3,
                decoration: BoxDecoration(
                  color: Color(0xfffd6a02),
                  gradient: LinearGradient(
                    colors: [Color(0xffef7215), Color(0xffffbf00)],
                    begin: Alignment.centerRight,
                    end: Alignment(-1.0, -1.0),
                  )
                ),
                child: myHeader(),
              ),
            ),

            Positioned(
              top:120.0,
              left:16.0,
              right:16.0,
              child: Container(
                color: Colors.transparent,
                width: 380.0,
                height: MediaQuery.of(context).size.height/1.5, //1.5
                child: ListView.builder(
                  itemCount: history.length,
                  itemBuilder: (context,position){
                    return Dismissible(
                      key: Key(history[position].toString()),
                      background: _myHiddenContainer(
                         history[position].status
                      ),
                      child: _myListContainer(
                        history[position].pickup,history[position].destination,history[position].cost,history[position].status
                      ),
                    
                    onDismissed: (direction){
                      if (direction == DismissDirection.startToEnd) {
                        Scaffold.of(context).showSnackBar(
                          SnackBar(content: Text("Delete"))
                        );
                      if(history.contains(history.removeAt(position))){
                        setState(() {
                          
                        });
                       }
                      }else{
                        if (direction == DismissDirection.endToStart) {
                          Scaffold.of(context).showSnackBar(
                            SnackBar(content: Text("Archive"))
                          );
                        }
                      }
                    },
                      );
                  }
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget myHeader(){
     return Align(
       child: ListTile(
         leading: Text('History',style:TextStyle(fontSize: 35.0,color:Colors.white)),
       ),
     );
  }

  Widget _myHiddenContainer(Color historyColor){
      return Container(
        height: MediaQuery.of(context).size.height,
        color: historyColor,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Align(
              alignment: Alignment.centerLeft,
              child: IconButton(
                icon: Icon(Icons.delete),
                color: Colors.white,
                onPressed: (){
                  setState(() {
                    
                  });
                },
              ),
            ),

            Align(
              alignment: Alignment.centerRight,
              child: IconButton(
                icon: Icon(Icons.archive),
                color: Colors.white,
                onPressed: (){
                  setState(() {
                    
                  });
                },
              ),
            ),
          ],
        ),
      );
  }

  Widget _myListContainer(String pickup, String destination, String cost, Color historyColor){
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        height: 200.0, //150.0
        child: Material(
          color: Colors.white,
          elevation: 14.0,
          borderRadius: BorderRadius.circular(24.0),
          shadowColor: Color(0x802196F3),
          child: Container(
            child: Row(
              children: <Widget>[
               /* Container(
                  height: 80.0,
                  width: 10.0,
                  color: historyColor,
                ), */
                SizedBox(width:20.0),
                Container (
                  height: 160.0,
                  //width: 50.0,
                  child:Column(
                    children:<Widget>[
                      Icon(
                        Icons.radio_button_checked,
                      ),
                      Container(height: 30, child: VerticalDivider(color: Colors.grey)),
                      Icon(
                        Icons.place,
                      ),
                    ]
                  )
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      ListTile(
                        leading: Text(pickup),
                      ),
                      ListTile(
                        leading: Text(destination),
                        ), 
                      Divider(color:Colors.grey[300]),
                      ListTile(
                        title: Text(cost),
                        trailing: Text('Completed',style:TextStyle(color:Colors.blueAccent,)),
                      ),
                     /* Align(
                        alignment: Alignment.topLeft,
                        child: Container(
                          child: Text(
                            ridename,
                            style:TextStyle(fontSize: 24.0,color: Colors.black,fontWeight: FontWeight.bold),
                          ),
                        ),
                        ),

                      Align(
                        alignment: Alignment.topLeft,
                        child: Container(
                          child: Text(
                            subride,
                            style:TextStyle(fontSize:18.0,color:Colors.blueAccent)),
                        ),
                      ),

                     Align(
                       alignment: Alignment.centerRight,
                       child: Padding(
                         padding: const EdgeInsets.all(8.0),
                         child: Container(
                           child: Text(
                             ridetime,
                             style: TextStyle(fontSize: 18.0,color: Colors.black45),
                             ),
                         ),
                       ),
                     ),    */ 
                    ],
                  ),  
                  ),
                )  
              ],
            ),
          ),
        ),
      ),
    );
  }

}
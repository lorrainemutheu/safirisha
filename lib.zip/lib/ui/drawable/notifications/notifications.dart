import 'package:flutter/material.dart';
import './add_notification.dart';

class NotificationPage extends StatefulWidget{
  @override
  State<StatefulWidget> createState() => _NotificationState();
}

class _NotificationState extends State<NotificationPage>{

    List<AddNotification> _notification = List(); 

    @override
    void initState(){
      super.initState();
      setState(() {
        _notification.add(AddNotification(Icon(Icons.check_circle),'System','Your booking #1234 has been successful'));
        _notification.add(AddNotification(Icon(Icons.receipt),'Promotion','Invite friends - Get 3 coupons each!'));
        _notification.add(AddNotification(Icon(Icons.receipt),'Promotion','Invite friends - Get 3 coupons each!'));
        _notification.add(AddNotification(Icon(Icons.cancel),'System','Your booking #1205 has been canceled'));
        _notification.add(AddNotification(Icon(Icons.account_balance_wallet),'System','Thank you! Your transaction is complete'));
      });
    }


    @override
    Widget build(BuildContext context){
      return Scaffold(
        appBar: AppBar(
          title: Text("Notifications"),
          backgroundColor: Colors.orangeAccent,
        ),
        body: ListView.builder(
           itemCount: _notification.length,
           itemBuilder: (BuildContext context, int index){
              return Card(
                child: Container(
                  padding:EdgeInsets.all(5.0),
                  child:ListTile(
                  leading: _notification[index].notIcon,
                  title: Text(_notification[index].notTitle),
                  subtitle: Text(_notification[index].notParagraph),
                  dense: true,
                  onTap: (){},
             ),
                ),
              );
           },
        ),
      );
    }
}


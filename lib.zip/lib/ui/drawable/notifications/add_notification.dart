import 'package:flutter/material.dart';

class AddNotification{

    Icon notIcon;
    String notTitle, notParagraph;

   AddNotification(this.notIcon,this.notTitle,this.notParagraph);

}
import 'package:flutter/material.dart';

class ShowDriverPage extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
      return FlatButton(
      onPressed: (){
        _showDriverCard(context);
              },
              child:Text(
                "APPLY",
                style:TextStyle(
                  color:Colors.white
                ),
              ),
            );
          }
        
           _showDriverCard(context) {
             return Center(
               child:Container(
                margin: EdgeInsets.only(left: 10.0, right: 10.0),
                child:SizedBox(
                  height: 220.0,
                  child: _buildCard(),
                ),
               ),
             );
          }

          Card _buildCard(){
             return Card(
                child: Column(
                   mainAxisSize: MainAxisSize.min,
                   children: <Widget>[
                     Container(
                      color: Colors.grey[200], 
                       child: ListTile(
                       leading: CircleAvatar(
                             radius: 24.0,
                             child:Image.asset(
                            "assets/kuikariuki.jpg",
                             width: 10,
                             height: 10,
                            fit: BoxFit.cover,
                          ),
                       ),
                       title: Text('John Doe',style: TextStyle(fontWeight: FontWeight.w400,)),
                       subtitle: Text('★4.9'),
                       trailing: Row(
                         children: <Widget>[
                           Icon(Icons.message),
                           SizedBox(width: 3.0,),
                           Icon(Icons.call),
                         ],
                       ), 
                     ),
                     ),
                     Divider(color: Colors.grey,),
                     Row(
                       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                       children: <Widget>[
                            Icon(Icons.local_shipping, color: Colors.black,size: 50.0,),
                            summaryBuilder('DISTANCE','0.2km'),
                            summaryBuilder('TIME','5min'),
                            summaryBuilder('PRICE','ksh 200'),
                       ],
                     ),
                    SizedBox(height:30.0,),
               RawMaterialButton(
                    onPressed: () {},
                    fillColor: Colors.orangeAccent,
                    constraints: BoxConstraints(minHeight: 50,minWidth: 250),
                    elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
                    child: Text('CONFIRM'),
                    textStyle: TextStyle(
                    //fontSize: 16,
                    fontFamily: 'QuickSand',
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
               ),
            ),  
                   ],
                ),
             );
          }

        Widget summaryBuilder(String title, String summary) {
           final Color tintColor = Colors.grey;
            return Column(
              children: <Widget>[
                 Text(title,style: TextStyle(fontWeight: FontWeight.w400),),
                 Container(
                  margin: const EdgeInsets.only(top: 5.0),
                  child: new Text(summary, style: new TextStyle(fontSize: 12.0,
                  fontWeight: FontWeight.w600, color: tintColor),),
                )
              ],
            );
        }
}

          
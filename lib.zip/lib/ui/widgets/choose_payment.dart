import 'package:flutter/material.dart';

class ChoosePaymentPage extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return _showPaymentBottomSheet(context);
      }
      
   _showPaymentBottomSheet(BuildContext context) {
          showModalBottomSheet(
             context: context,
             builder: (BuildContext context){
               return Container(
                height: 300,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(20),
                    topRight: Radius.circular(20),
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        _createTile(Icons.local_shipping, 'Canter', '5min away', 'ksh 200'),
                      ],
                    ),
                  ],
                ),
               );
             }
          );
   }

   ListTile _createTile(IconData icon, String carType, String time, String price){
                  return ListTile(
                    leading: Icon(icon),
                    title: Text(carType),
                    subtitle: Text(time),
                    dense: true,
                    trailing: Text(price),
                  );
              }
}
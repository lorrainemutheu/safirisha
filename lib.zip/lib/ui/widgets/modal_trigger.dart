import 'package:flutter/material.dart';
//import './choose_payment.dart';

class ModalTrigger extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return FlatButton(
      onPressed: (){
        _showModalBottomSheet(context);
      },
      child:Text(
        "APPLY",
        style:TextStyle(
          color:Colors.white
        ),
      ),
    );
  }

//display modalbottomsheet
    _showModalBottomSheet(context){
       showModalBottomSheet(
         context: context, 
         builder:(BuildContext context){
           return Container(
             height: 300,
             decoration: BoxDecoration(
               color: Colors.white,
               borderRadius: BorderRadius.only(
                 topLeft: Radius.circular(20),
                 topRight: Radius.circular(20),
               ),
             ),
             child: _myListView(context),
           );
         }
      );
    } 

  final carIcon = [Icons.local_shipping,Icons.directions_car,Icons.airport_shuttle,Icons.motorcycle];
  final carType = ['Lorry','Pickup','Van','MotorBike'];
  final price = ['ksh 800','ksh 400', 'ksh 500', 'ksh 200'];
  final time = ['5min away', '10min away', '15min away', '20min away']; 

  ListView _myListView(BuildContext context){
       return ListView.separated(
         itemCount: carType.length,
         itemBuilder: (context, index){
            return ListTile(
              leading: Icon(carIcon[index],size: 40.0,),
              title: Text(carType[index]),
              subtitle: Text(time[index]),
              dense: true,
              trailing: Text(price[index]),
              onTap: (){
                Navigator.pop(context);
                //print(carType[index]);
                //Navigator.push(context,MaterialPageRoute(builder: (context) => ChoosePaymentPage()),);
                //Navigator.of(context).pushNamed('/signup');
                _showPaymentBottomSheet(context);
              },
            );
         },
         separatorBuilder:(context,index){
           return Divider();
         },
       );
  } 

  _showPaymentBottomSheet(context){
    showModalBottomSheet(
      context: context, 
      builder:(BuildContext context){
        return Container(
         color: Color(0xFF737373),
         height: 250,
         child:Container(
         // height: 300,
          //check to see difference if child is placed here
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(20),
              topRight: Radius.circular(20),
            ),
          ),
         child:_buildColumnModal(),
         )
        );
      }
  );
}

    Column _buildColumnModal(){
       return Column(
         mainAxisSize: MainAxisSize.min,
         children: <Widget>[
           Container(
             color: Colors.grey[200],
             child:ListTile(
              leading: Icon(Icons.local_shipping,size:40.0),
              title: Text('Lorry'),
              subtitle: Text('5mins away'),
              dense: true,
              trailing: Text('ksh 800'),
              ),
            ),
           Container(
            height: 1.0,
            color: Colors.grey,
           ),
           SizedBox(height:15.0),
           Row(
             mainAxisAlignment: MainAxisAlignment.spaceEvenly,
             children: <Widget>[
                buildButton(Icons.account_balance_wallet,'Payment'),
                Container(height: 80, child: VerticalDivider(color: Colors.grey)),
                buildButton(Icons.receipt,'Promo-code'),
                Container(height: 80, child: VerticalDivider(color: Colors.grey)),
                buildButton(Icons.more_horiz,'Options'),
             ],
             ),
            SizedBox(height:30.0,),
           // Container(
               RawMaterialButton(
                    onPressed: () {},
                    fillColor: Colors.orangeAccent,
                    constraints: BoxConstraints(minHeight: 50,minWidth: 250),
                    elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
                    child: Text('REQUEST'),
                    textStyle: TextStyle(
                    //fontSize: 16,
                    fontFamily: 'QuickSand',
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
               ),
            ), 
         // ),  
         ],
         );
    }

    Widget buildButton(IconData icon, String buttonTitle) {
      final Color tintColor = Colors.grey;
      return new Column(
        children: <Widget>[
          new Icon(icon, color: tintColor),
          new Container(
            margin: const EdgeInsets.only(top: 5.0),
            child: new Text(buttonTitle, style: new TextStyle(fontSize: 12.0,
            fontWeight: FontWeight.w600, color: tintColor),),
          )
        ],
      );
    }
    /*  ListTile _createTile(IconData icon, String carType, String time, String price){
                  return ListTile(
                    leading: Icon(icon),
                    title: Text(carType),
                    subtitle: Text(time),
                    dense: true,
                    trailing: Text(price),
                  );
              } */
         } 

            /*  ListTile _createTile(BuildContext context, IconData icon, String carType, String time, String price, Function action){
                  return ListTile(
                    leading: Icon(icon),
                    title: Text(carType),
                    subtitle: Text(time),
                    dense: true,
                    trailing: Text(price),
                    onTap: (){
                      Navigator.pop(context);
                      action();
                    },
                  );
              } */

            /*child:ListView(
               children:ListTile.divideTiles(
                 context:context,
                 tiles:[
                 _createTile(context, Icons.local_shipping, 'Canter', '5min away', 'ksh 200',  _action1),
                 _createTile(context, Icons.local_shipping, 'Canter', '5min away', 'ksh 200',  _action1),
                 _createTile(context, Icons.local_shipping, 'Canter', '5min away', 'ksh 200',  _action1),
                 _createTile(context, Icons.local_shipping, 'Canter', '5min away', 'ksh 200',  _action1),
                 ]
                  RawMaterialButton(
                    onPressed: () {},
                    fillColor: Colors.orangeAccent,
                    constraints: BoxConstraints(minHeight: 50),
                    elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
                    child: Text('PROCEED'),
                    textStyle: TextStyle(
                    fontSize: 16,
                    fontFamily: 'QuickSand',
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
               ),
             ), 
               ).toList()
            ), */
import 'package:flutter/material.dart';

const Color black =  Colors.black;
const Color white =  Colors.white;
import 'package:flutter/material.dart';
import './ui/homepage.dart';
import './ui/login.dart';
import './ui/sign_up.dart';
import './ui/get_ride.dart';
import './ui/set_location.dart';
import './ui/drawable/history/history.dart';
import './ui/drawable/notifications/notifications.dart';
import  './ui/ratings.dart';

/* void main(){
  runApp(
    new MaterialApp(
      theme: ThemeData(primaryColor:Colors.red,accentColor:Colors.yellowAccent),
      home: new Home(),
    )
  );
} */

void main() => runApp(MyApp());

class MyApp extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Ratings(),
      routes: <String,WidgetBuilder>{
        "/homepage":(BuildContext context)=>new HomePage(),
        "/getride":(BuildContext context)=>new MyHomePage(),
        "/loginpage":(BuildContext context)=>new LoginPage(),
        "/signup":(BuildContext context)=>new SignUpPage(),
        "/setlocation":(BuildContext context)=>new LocationPage(),
        "/history":(BuildContext context)=>new HistoryPage(),
        "/notifications":(BuildContext context)=>new NotificationPage(),
        "/ratings":(BuildContext context)=>new Ratings()
      },
    );
  }
    
}
